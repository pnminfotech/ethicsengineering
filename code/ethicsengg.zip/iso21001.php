<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Ethics Engineering & Consultancy</title>
    <meta name="description" content="Ethics Engineering & Consultancy">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png">
    <!-- Place favicon.ico in the root directory -->
    <!-- CSS here -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/animate.min.css">
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <link rel="stylesheet" href="assets/css/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/css/flaticon.css">
    <link rel="stylesheet" href="assets/css/odometer.css">
    <link rel="stylesheet" href="assets/css/swiper-bundle.css">
    <link rel="stylesheet" href="assets/css/aos.css">
    <link rel="stylesheet" href="assets/css/default.css">
    <link rel="stylesheet" href="assets/css/main.css">
</head>
<body>
    <!--Preloader-->
    <div id="preloader">
        <div id="loader" class="loader">
            <div class="loader-container">
                <div class="loader-icon"><img src="assets/img/logo/preloader.png" alt="Preloader"></div>
            </div>
        </div>
    </div>
    <!--Preloader-end -->
    <!-- Scroll-top -->
    <button class="scroll__top scroll-to-target" data-target="html">
        <i class="fas fa-angle-up"></i>
    </button>
    <!-- Scroll-top-end-->
   

    <?php include 'header.php'; ?>



    <!-- main-area -->
    <main class="fix">
        <!-- breadcrumb-area -->
        <section class="breadcrumb__area breadcrumb__bg" data-background="assets/img/bg/bread1.jpg">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="breadcrumb__content">
                            <h2 class="title">ISO 21001</h2>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href='index.php'>Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">
                                    ISO 21001 : 2011 Educational Organisation Management System</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <div class="breadcrumb__shape">
                <img src="assets/img/images/breadcrumb_shape01.png" alt="">
                <img src="assets/img/images/breadcrumb_shape02.png" alt="" class="rightToLeft">
                <img src="assets/img/images/breadcrumb_shape03.png" alt="">
                <img src="assets/img/images/breadcrumb_shape04.png" alt="">
                <img src="assets/img/images/breadcrumb_shape05.png" alt="" class="alltuchtopdown">
            </div>
        </section>


        <!-- breadcrumb-area-end -->
              <!-- services-details-area -->
              <section class="services__details-area">
            <div class="container">
                <div class="services__details-wrap">
                    <div class="row">
                    <div class="col-70 order-0 order-lg-2">
                            <div class="services__details-content services__details-content-two">
                                <h2 class="title">ISO 21001 : 2011 Educational Organisation Management System</h2>
                                <p>ISO 21001:2011 is an international standard that specifies requirements for an Educational Organization Management System (EOMS). The standard was published in 2018, not 2011 as you mentioned. ISO 21001:2018 is designed to help educational organizations, such as schools, universities, and training centers, establish and implement effective management systems to enhance the quality of education and learning outcomes.</p>
                                <div class="services__details-thumb">
                                    <img src="assets/img/services/iso21001.jpeg" alt="">
                                </div>
                                <div class="services__details-inner-three">
                                    <div class="row gutter-24 align-items-center">
                                       
                                        <div class="col-md-12">
                                            <div class="services__details-inner-content-one">
                                                <h4 >Key features of ISO 21001:2011 include:</h4>
                                                <div class="about__list-box about__list-box-three">
                                                    <ul class="list-wrap">
                                                     

                                                      <li><i class="flaticon-arrow-button"></i><p><b> Scope: </b>The standard outlines the requirements for an Educational Organization Management System (EOMS) that can be applied to any organization that provides educational products and services.</p> </li>
                                                      <li><i class="flaticon-arrow-button"></i><p><b>Context of the Organization:: </b>ISO 21001 emphasizes the importance of understanding the internal and external factors that can affect the organization's ability to achieve its educational objectives.</p></li>
                                                      <li><i class="flaticon-arrow-button"></i><p><b>Leadership and Governance: </b> The standard requires top management to demonstrate leadership and commitment to the EOMS. It also addresses the need for an effective governance structure within the educational organization.</p> 
</li>
                                                      <li><i class="flaticon-arrow-button"></i><p><b>Competence of Personnel: </b>ISO 21001 emphasizes the importance of ensuring that personnel have the necessary competence to fulfill their roles and responsibilities within the educational organization.</p> </li>
                                                    <li><i class="flaticon-arrow-button"></i><p><b>Learning Environment:</b>The standard highlights the significance of creating a conducive and effective learning environment, considering factors such as facilities, resources, and support services.</p> </li>
                                                    <li><i class="flaticon-arrow-button"></i><p><b>Design and Development of Educational Products and Services: </b>ISO 21001 outlines requirements for the design and development of educational products and services to meet the specified learning objectives.</p> </li>
                                                    <li><i class="flaticon-arrow-button"></i><p><b>Assessment and Monitoring of Learner Achievement: </b>The standard addresses the assessment and monitoring of learner performance and achievement, emphasizing the use of valid and reliable methods.</p> </li>
                                                    <li><i class="flaticon-arrow-button"></i><p><b>Continual Improvement:  </b> ISO 21001 encourages educational organizations to continually monitor and improve their EOMS to enhance the effectiveness of education delivery.</p> </li>
                                                    

                                                    </ul>
                                                    <p>It's important to note that ISO standards are periodically reviewed and updated. Therefore, it's recommended to check for the latest version or amendments to ISO 21001 .</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            
                            </div>
                        </div>
                        <div class="col-30">
                            <aside class="services__sidebar">
                                <div class="sidebar__widget sidebar__widget-three">
                                    <div class="sidebar__cat-list-two sidebar__cat-list-three">
                                        <ul class="list-wrap">
                                        <li><a href="iso9001.php">ISO 9001 :2015</a></li>
                                        <li><a href="iso14001.php">ISO 14001 : 2015</a></li>
                                        <li><a href="iso27001.php">ISO 27001 : 2022</a></li>
                                        <li><a href="iso13485.php">ISO 13485 : 2016</a></li>
                                        <li><a href="iso17025.php">ISO 17025 : 2017</a></li>
                                        <li><a href="iso50001.php">ISO 50001 : 2018</a></li>
                                        <li><a href="iso31000.php">ISO 31000 : 2018</a></li>
                                        <li><a href="iso21001.php">ISO 21001 : 2011</a></li>
                                        <li><a href="iso22000.php">ISO 22000 : 2011</a></li>
                                        <li><a href="iso22301.php">ISO 22301 :2019</a></li>
                                        </ul>
                                    </div>
                                </div>
                                
                                <div class="sidebar__widget sidebar__widget-three">
                                    <h4 class="sidebar__widget-title">Certificate</h4>
                                    <div class="sidebar__brochure sidebar__brochure-two">
                                        <img src="assets/img/certificate/certificate.webp">
                                    </div>
                                </div>
                                <div class="sidebar__widget sidebar__widget-two">
                                    <div class="sidebar__contact sidebar__contact-two" data-background="assets/img/services/sidebar_contact_bg.jpg">
                                        <h2 class="title">If You Need Any Help Contact With Us</h2>
                                        <a href="tel:+919923645571" class="btn"><i class="flaticon-phone-call"></i>+91 99 23 645 571</a>
                                    </div>
                                </div>
                            </aside>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- services-details-area-end -->
       
      
    </main>
    <!-- main-area-end -->
    <!-- footer-area -->
    <?php include 'footer.php' ?>
    <!-- footer-area-end -->
    <!-- JS here -->
    <script src="assets/js/vendor/jquery-3.6.0.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/jquery.odometer.min.js"></script>
    <script src="assets/js/jquery.appear.js"></script>
    <script src="assets/js/gsap.js"></script>
    <script src="assets/js/ScrollTrigger.js"></script>
    <script src="assets/js/SplitText.js"></script>
    <script src="assets/js/gsap-animation.js"></script>
    <script src="assets/js/jquery.parallaxScroll.min.js"></script>
    <script src="assets/js/swiper-bundle.js"></script>
    <script src="assets/js/ajax-form.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/aos.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>