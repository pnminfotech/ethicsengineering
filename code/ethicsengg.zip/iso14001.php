<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Ethics Engineering & Consultancy</title>
    <meta name="description" content="Ethics Engineering & Consultancy">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png">
    <!-- Place favicon.ico in the root directory -->
    <!-- CSS here -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/animate.min.css">
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <link rel="stylesheet" href="assets/css/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/css/flaticon.css">
    <link rel="stylesheet" href="assets/css/odometer.css">
    <link rel="stylesheet" href="assets/css/swiper-bundle.css">
    <link rel="stylesheet" href="assets/css/aos.css">
    <link rel="stylesheet" href="assets/css/default.css">
    <link rel="stylesheet" href="assets/css/main.css">
</head>
<body>
    <!--Preloader-->
    <div id="preloader">
        <div id="loader" class="loader">
            <div class="loader-container">
                <div class="loader-icon"><img src="assets/img/logo/preloader.png" alt="Preloader"></div>
            </div>
        </div>
    </div>
    <!--Preloader-end -->
    <!-- Scroll-top -->
    <button class="scroll__top scroll-to-target" data-target="html">
        <i class="fas fa-angle-up"></i>
    </button>
    <!-- Scroll-top-end-->
   

    <?php include 'header.php'; ?>



    <!-- main-area -->
    <main class="fix">
        <!-- breadcrumb-area -->
        <section class="breadcrumb__area breadcrumb__bg" data-background="assets/img/bg/bread1.jpg">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="breadcrumb__content">
                            <h2 class="title">ISO 14001</h2>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href='index.php'>Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">ISO 14001 : 2015 Environmental Management System</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <div class="breadcrumb__shape">
                <img src="assets/img/images/breadcrumb_shape01.png" alt="">
                <img src="assets/img/images/breadcrumb_shape02.png" alt="" class="rightToLeft">
                <img src="assets/img/images/breadcrumb_shape03.png" alt="">
                <img src="assets/img/images/breadcrumb_shape04.png" alt="">
                <img src="assets/img/images/breadcrumb_shape05.png" alt="" class="alltuchtopdown">
            </div>
        </section>


        <!-- breadcrumb-area-end -->
              <!-- services-details-area -->
              <section class="services__details-area">
            <div class="container">
                <div class="services__details-wrap">
                    <div class="row">
                    <div class="col-70 order-0 order-lg-2">
                            <div class="services__details-content services__details-content-two">
                                <h2 class="title">ISO 14001 : 2015 Environmental Management System</h2>
                                <p>ISO 14001:2015 is an international standard that specifies the requirements for an environmental management system (EMS). An EMS is a framework that helps organizations identify, manage, monitor, and improve their environmental performance. The ISO 14001 standard is designed to be applicable to any organization, regardless of its size, type, or nature.</p>
                                <div class="services__details-thumb">
                                    <img src="assets/img/services/iso14001.jpeg" alt="">
                                </div>
                                <div class="services__details-inner-three">
                                    <div class="row gutter-24 align-items-center">
                                       
                                        <div class="col-md-12">
                                            <div class="services__details-inner-content-one">
                                                <h4 >Key elements of ISO 14001:2015 include:</h4>
                                                <h4>Context of the Organization:</h4>
                                                <div class="about__list-box about__list-box-three">
                                                    <ul class="list-wrap">
                                                      <li><p> Understanding the organization and its context in relation to the environment. Identifying and understanding the needs and expectations of interested parties.</p></li>

                                                      <li><i class="flaticon-arrow-button"></i><p><b>  Leadership: </b>Top management commitment and leadership in establishing and maintaining the EMS. Establishing environmental policy and organizational roles, responsibilities, and authorities.</p> </li>
                                                      <li><i class="flaticon-arrow-button"></i><p><b>Planning: </b>Identifying environmental aspects and impacts of activities, products, or services. Legal and other requirements related to environmental aspects. Setting environmental objectives and planning actions to achieve them.</p></li>
                                                      <li><i class="flaticon-arrow-button"></i><p><b>Support:</b>Resources, competence, awareness, communication, and documented information necessary for the EMS.</p> </li>
                                                      <li><i class="flaticon-arrow-button"></i><p><b>Operation:</b>Operational planning and control to manage environmental aspects. Emergency preparedness and response.</p> </li>
                                                    <li><i class="flaticon-arrow-button"></i><p><b>Performance Evaluation: </b>Monitoring, measurement, analysis, and evaluation of the EMS.
Internal audit of the EMS. Management review of the EMS.</p> </li>
                                                    <li><i class="flaticon-arrow-button"></i><p><b>Improvement: </b>Nonconformity and corrective action.
Continual improvement of the EMS.</p> </li>




                                                    </ul>
                                                    <p>Organizations that implement ISO 14001:2015 demonstrate their commitment to environmental responsibility and sustainability. The standard provides a systematic approach to managing environmental aspects, complying with legal requirements, and continually improving environmental performance. It's important for organizations to undergo periodic internal audits and management reviews to ensure the effectiveness of their EMS and identify opportunities for improvement. Certification to ISO 14001:2015 by an accredited certification body is optional but can be sought by organizations as a way to demonstrate their compliance with the standard to external stakeholders.</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            
                            </div>
                        </div>
                        <div class="col-30">
                            <aside class="services__sidebar">
                                <div class="sidebar__widget sidebar__widget-three">
                                    <div class="sidebar__cat-list-two sidebar__cat-list-three">
                                        <ul class="list-wrap">
                                        <li><a href="iso9001.php">ISO 9001 :2015</a></li>
                                        <li><a href="iso14001.php">ISO 14001 : 2015</a></li>
                                        <li><a href="iso27001.php">ISO 27001 : 2022</a></li>
                                        <li><a href="iso13485.php">ISO 13485 : 2016</a></li>
                                        <li><a href="iso17025.php">ISO 17025 : 2017</a></li>
                                        <li><a href="iso50001.php">ISO 50001 : 2018</a></li>
                                        <li><a href="iso31000.php">ISO 31000 : 2018</a></li>
                                        <li><a href="iso21001.php">ISO 21001 : 2011</a></li>
                                        <li><a href="iso22000.php">ISO 22000 : 2011</a></li>
                                        <li><a href="iso22301.php">ISO 22301 :2019</a></li>
                                        </ul>
                                    </div>
                                </div>
                                
                                <div class="sidebar__widget sidebar__widget-three">
                                    <h4 class="sidebar__widget-title">Certificate</h4>
                                    <div class="sidebar__brochure sidebar__brochure-two">
                                        <img src="assets/img/certificate/certificate.webp">
                                    </div>
                                </div>
                                <div class="sidebar__widget sidebar__widget-two">
                                    <div class="sidebar__contact sidebar__contact-two" data-background="assets/img/services/sidebar_contact_bg.jpg">
                                        <h2 class="title">If You Need Any Help Contact With Us</h2>
                                        <a href="tel:+919923645571" class="btn"><i class="flaticon-phone-call"></i>+91 99 23 645 571</a>
                                    </div>
                                </div>
                            </aside>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- services-details-area-end -->
       
      
    </main>
    <!-- main-area-end -->
    <!-- footer-area -->
    <?php include 'footer.php' ?>
    <!-- footer-area-end -->
    <!-- JS here -->
    <script src="assets/js/vendor/jquery-3.6.0.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/jquery.odometer.min.js"></script>
    <script src="assets/js/jquery.appear.js"></script>
    <script src="assets/js/gsap.js"></script>
    <script src="assets/js/ScrollTrigger.js"></script>
    <script src="assets/js/SplitText.js"></script>
    <script src="assets/js/gsap-animation.js"></script>
    <script src="assets/js/jquery.parallaxScroll.min.js"></script>
    <script src="assets/js/swiper-bundle.js"></script>
    <script src="assets/js/ajax-form.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/aos.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>